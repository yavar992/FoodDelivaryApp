package com.foodDelivaryApp.userservice.service;

public interface OfferService {
}
