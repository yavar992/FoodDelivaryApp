package com.foodDelivaryApp.userservice.DTO;

import lombok.Data;

@Data
public class VerifyOTP {

    private Integer otp;

}
