package com.foodDelivaryApp.userservice.service;

public interface WalletService {
}
