package com.foodDelivaryApp.userservice.entity;

public enum WalletMethodEnum {

    FROM_REFERRAL,
    FROM_PURCHASE,
    JOIN_BONUS,
    FROM_REFUND;


}
