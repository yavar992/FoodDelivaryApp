package com.foodDelivaryApp.userservice.entity;

public enum ReferralMethodEnum {

    EMAIL , PHONE
}
