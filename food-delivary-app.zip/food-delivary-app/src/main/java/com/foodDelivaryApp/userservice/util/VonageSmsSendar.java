package com.foodDelivaryApp.userservice.util;



public class VonageSmsSendar {
//
//    VonageClient client = VonageClient.builder().apiKey("0f397793").apiSecret("RgGxduYwc1Fj6UF0").build();
//    TextMessage message = new TextMessage("Vonage APIs",
//            "918865007699",
//            "A text message sent using the Vonage SMS API"
//    );
//
//    SmsSubmissionResponse response = client.getSmsClient().submitMessage(message);
//
//if (response.getMessages().get(0).getStatus() == MessageStatus.OK) {
//        System.out.println("Message sent successfully.");
//    } else {
//        System.out.println("Message failed with error: " + response.getMessages().get(0).getErrorText());
//    }

    }


