package com.foodDelivaryApp.userservice.entity;

public enum TransactionEnum {

    CREDIT , DEBIT
}
