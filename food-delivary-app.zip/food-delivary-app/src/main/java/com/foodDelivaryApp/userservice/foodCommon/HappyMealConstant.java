package com.foodDelivaryApp.userservice.foodCommon;

public class HappyMealConstant {

    public static final String SOMETHING_WENT_WRONG =  "SOMETHING WENT WRONG";
}
