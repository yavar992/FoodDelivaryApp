package com.foodDelivaryApp.userservice.validator;

public class ValidateOTP {


}
